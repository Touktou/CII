 // ---------- MULTI-LANGUAGE DICTIONARY (EN / FR) ----------
  const translations = {
    en: {
      brand: "CommUnity",
      nav_home: "Home", nav_gallery: "Gallery", nav_events: "Events", nav_activities: "Activities", nav_aboutus: "About Us" ,nav_donation: "Donation", nav_contact: "Contact",
      home_title: "Welcome to CommUnity 🌱", home_sub: "A place where neighbors become family. Discover resources, join activities, or support our mission.",
      home_explore: "Explore Catalogue", home_activities: "See Activities",
      feature1_title: "Community Store", feature1_desc: "Handmade goods & local produce",
      feature2_title: "Weekly Meetups", feature2_desc: "Gardening, yoga & skill sharing",
      feature3_title: "Support Us", feature3_desc: "Your donation fuels our programs",
      catalogue_title: "Community Catalogue", catalogue_desc: "Locally crafted goods, art, and fresh harvest — every purchase supports our projects.",
      activities_title: "Upcoming Activities", activities_desc: "Join us, learn, and connect with wonderful people.",
      donation_title: "Make a Difference", donation_desc: "Your generous donation helps us run free workshops, maintain community gardens, and support local families.",
      donation_name: "Full Name", donation_email: "Email", donation_amount_label: "Donation Amount ($)",
      opt_10: "$10 - Plants a sapling 🌿", opt_25: "$25 - Supports a workshop 🧑‍🌾", opt_50: "$50 - Community meal 🍲", opt_100: "$100 - Sponsor a family 📚", opt_other: "Other amount",
      custom_amount_label: "Custom amount ($)", donation_message_label: "Message (optional)", donate_btn: "Donate Now", donation_footer: "❤️ 100% of contributions go to community programs.",
      contact_title: "Get in Touch", contact_desc: "We’d love to hear from you — questions, collaboration, or just saying hello.",
      contact_name_label: "Your Name", contact_email_label: "Email", contact_msg_label: "Message", contact_send: "Send Message",
      footer: "🌍 CommUnity — bridging hearts, building futures. © 2025 | Together we thrive",
      // dynamic product names & activities (catalogue / activities)
      product1: "Handmade Ceramic Mug", product1_desc: "Earth-toned, crafted by local artists", price_symbol: "$",
      product2: "Organic Honey Jar", product2_desc: "Raw, unfiltered from community bees",
      product3: "Knitted Scarf", product3_desc: "Wool blend, fair-trade",
      product4: "Herb Garden Kit", product4_desc: "Basil, mint & cilantro seeds + soil",
      product5: "Community Cookbook", product5_desc: "50 family recipes from neighbors",
      product6: "Reusable Tote Bag", product6_desc: "Eco-friendly, screen printed",
      interested_btn: "Interested",
      join_event: "Join Event →",
      activity_weekend: "🌿 Weekend Gardening Club", activity_art: "🎨 Art & Craft Circle", activity_meditation: "🧘 Morning Meditation & Tea",
      activity_workshop: "💻 Digital Skills Workshop", activity_potluck: "🍲 Potluck & Story Night",
      location_garden: "Garden of Hope", location_hall: "Community Hall", location_wellness: "Wellness Center", location_library: "Library Hub", location_square: "Main Square",
      date_weekend: "Sat, May 17 · 10:00 AM", date_art: "Mon, May 19 · 6:00 PM", date_meditation: "Wed, May 21 · 8:30 AM", date_workshop: "Fri, May 23 · 3:00 PM", date_potluck: "Sun, May 25 · 5:00 PM",
      spots_available: "spots available",
      toast_interest: "✨ Added \"{product}\" to your interest list! We'll contact you.",
      toast_joined: "🎉 You joined \"{activity}\"! We'll send reminders.",
      toast_donation_thanks: "💚 Thank you {name}! Your donation of {amount} will transform lives.",
      toast_contact_thanks: "📬 Thanks {name}, we've received your message. We'll reply within 48h."
    },
    fr: {
      brand: "CommUnity", nav_home: "Accueil", nav_catalogue: "Catalogue", nav_activities: "Activités", nav_donation: "Don", nav_contact: "Contact",
      home_title: "Bienvenue à CommUnity 🌱", home_sub: "Un endroit où les voisins deviennent une famille. Découvrez des ressources, participez à des activités ou soutenez notre mission.",
      home_explore: "Explorer le catalogue", home_activities: "Voir les activités",
      feature1_title: "Boutique communautaire", feature1_desc: "Produits artisanaux et produits locaux",
      feature2_title: "Rencontres hebdomadaires", feature2_desc: "Jardinage, yoga et partage de compétences",
      feature3_title: "Soutenez-nous", feature3_desc: "Votre don alimente nos programmes",
      catalogue_title: "Catalogue communautaire", catalogue_desc: "Produits artisanaux, art et récoltes fraîches — chaque achat soutient nos projets.",
      activities_title: "Activités à venir", activities_desc: "Rejoignez-nous, apprenez et connectez-vous avec des personnes merveilleuses.",
      donation_title: "Faire la différence", donation_desc: "Votre don généreux nous aide à organiser des ateliers gratuits, entretenir des jardins communautaires et soutenir les familles locales.",
      donation_name: "Nom complet", donation_email: "Email", donation_amount_label: "Montant du don ($)",
      opt_10: "10 $ - Plante un arbre 🌿", opt_25: "25 $ - Soutient un atelier 🧑‍🌾", opt_50: "50 $ - Repas communautaire 🍲", opt_100: "100 $ - Parraine une famille 📚", opt_other: "Autre montant",
      custom_amount_label: "Montant personnalisé ($)", donation_message_label: "Message (optionnel)", donate_btn: "Faire un don", donation_footer: "❤️ 100 % des contributions vont aux programmes communautaires.",
      contact_title: "Contactez-nous", contact_desc: "Nous serions ravis de vous entendre — questions, collaborations ou simplement dire bonjour.",
      contact_name_label: "Votre nom", contact_email_label: "Email", contact_msg_label: "Message", contact_send: "Envoyer le message",
      footer: "🌍 CommUnity — unir les cœurs, bâtir l'avenir. © 2025 | Ensemble, nous prospérons",
      product1: "Tasse en céramique artisanale", product1_desc: "Tons terreux, fabriquée par des artisans locaux", price_symbol: "$",
      product2: "Pot de miel biologique", product2_desc: "Cru, non filtré des abeilles de la communauté",
      product3: "Écharpe tricotée", product3_desc: "Mélange de laine, commerce équitable",
      product4: "Kit de jardin d'herbes", product4_desc: "Graines de basilic, menthe et coriandre + terreau",
      product5: "Livre de recettes communautaire", product5_desc: "50 recettes familiales des voisins",
      product6: "Sac réutilisable", product6_desc: "Écologique, sérigraphié",
      interested_btn: "Intéressé(e)",
      join_event: "Rejoindre →",
      activity_weekend: "🌿 Club de jardinage du week-end", activity_art: "🎨 Cercle d'art et d'artisanat", activity_meditation: "🧘 Méditation matinale et thé",
      activity_workshop: "💻 Atelier de compétences numériques", activity_potluck: "🍲 Auberge espagnole et soirée contes",
      location_garden: "Jardin de l'Espoir", location_hall: "Salle communautaire", location_wellness: "Centre de bien-être", location_library: "Pôle médiathèque", location_square: "Place centrale",
      date_weekend: "Sam 17 mai · 10h00", date_art: "Lun 19 mai · 18h00", date_meditation: "Mer 21 mai · 8h30", date_workshop: "Ven 23 mai · 15h00", date_potluck: "Dim 25 mai · 17h00",
      spots_available: "places disponibles",
      toast_interest: "✨ Ajouté \"{product}\" à votre liste d'intérêts ! Nous vous contacterons.",
      toast_joined: "🎉 Vous avez rejoint \"{activity}\" ! Nous enverrons des rappels.",
      toast_donation_thanks: "💚 Merci {name} ! Votre don de {amount} va transformer des vies.",
      toast_contact_thanks: "📬 Merci {name}, nous avons reçu votre message. Nous vous répondrons sous 48h."
    }
  };

  let currentLang = "en";

  function updatePageLanguage() {
    const elements = document.querySelectorAll('[data-i18n]');
    elements.forEach(el => {
      const key = el.getAttribute('data-i18n');
      if (translations[currentLang][key]) {
        if (el.tagName === 'INPUT' || el.tagName === 'TEXTAREA' || el.tagName === 'SELECT') {
          if (el.placeholder !== undefined) el.placeholder = translations[currentLang][key];
          else el.innerText = translations[currentLang][key];
        } else {
          el.innerText = translations[currentLang][key];
        }
      }
    });
    // Update select options with data-i18n
    document.querySelectorAll('select option[data-i18n]').forEach(opt => {
      const key = opt.getAttribute('data-i18n');
      if (translations[currentLang][key]) opt.textContent = translations[currentLang][key];
    });
    // re-render dynamic content (catalogue & activities)
    rendergallery();
    renderActivities();
    // update donation select's other text after rerender
    const amountSelect = document.getElementById('donationAmount');
    if(amountSelect) {
      const otherOption = amountSelect.querySelector('option[value="other"]');
      if(otherOption && translations[currentLang].opt_other) otherOption.textContent = translations[currentLang].opt_other;
    }
  }

  // ---- DATA (same structure, but names/descs come from lang dict) ----
  function getgalleryItems() {
    return [
      { id: 1, nameKey: "product1", descKey: "product1_desc", price: "18", icon: "fa-mug-hot" },
      { id: 2, nameKey: "product2", descKey: "product2_desc", price: "12", icon: "fa-jar" },
      { id: 3, nameKey: "product3", descKey: "product3_desc", price: "24", icon: "fa-tshirt" },
      { id: 4, nameKey: "product4", descKey: "product4_desc", price: "15", icon: "fa-seedling" },
      { id: 5, nameKey: "product5", descKey: "product5_desc", price: "22", icon: "fa-book" },
      { id: 6, nameKey: "product6", descKey: "product6_desc", price: "9", icon: "fa-bag-shopping" },
      { id: 5, nameKey: "product5", descKey: "product5_desc", price: "22", icon: "fa-book" },
      { id: 6, nameKey: "product6", descKey: "product6_desc", price: "9", icon: "fa-bag-shopping" }
    ];
  }

  function getActivitiesList() {
    return [
      { id: 1, titleKey: "activity_weekend", dateKey: "date_weekend", locationKey: "location_garden", spots: 12 },
      { id: 2, titleKey: "activity_art", dateKey: "date_art", locationKey: "location_hall", spots: 20 },
      { id: 3, titleKey: "activity_meditation", dateKey: "date_meditation", locationKey: "location_wellness", spots: 15 },
      { id: 4, titleKey: "activity_workshop", dateKey: "date_workshop", locationKey: "location_library", spots: 10 },
      { id: 5, titleKey: "activity_potluck", dateKey: "date_potluck", locationKey: "location_square", spots: 30 }
    ];
  }

  function rendergallery() {
    const container = document.getElementById('galleryGrid');
    if (!container) return;
    const items = getgalleryItems();
    container.innerHTML = items.map(item => `
      <div class="gallery-card">
        <i class="fas ${item.icon}"></i>
        <h3>${translations[currentLang][item.nameKey]}</h3>
        <p>${translations[currentLang][item.descKey]}</p>
        <div class="price">${translations[currentLang].price_symbol}${item.price}</div>
        <button class="btn btn-outline add-to-cart-btn" data-name="${translations[currentLang][item.nameKey]}" style="width:100%; margin-top:6px;"><i class="fas fa-cart-plus"></i> ${translations[currentLang].interested_btn}</button>
      </div>
    `).join('');
    document.querySelectorAll('.add-to-cart-btn').forEach(btn => {
      btn.addEventListener('click', (e) => {
        const productName = btn.getAttribute('data-name');
        let msg = translations[currentLang].toast_interest.replace("{product}", productName);
        showToast(msg);
      });
    });
  }

  function renderActivities() {
    const container = document.getElementById('activityList');
    if (!container) return;
    const acts = getActivitiesList();
    container.innerHTML = acts.map(act => `
      <div class="activity-item">
        <div style="display:flex; justify-content:space-between; flex-wrap:wrap; align-items:center;">
          <div><strong style="font-size:1.2rem;">${translations[currentLang][act.titleKey]}</strong><br>
          <i class="fas fa-calendar-day"></i> ${translations[currentLang][act.dateKey]} &nbsp;|&nbsp; <i class="fas fa-location-dot"></i> ${translations[currentLang][act.locationKey]}<br>
          <span style="font-size:0.85rem;">👥 ${act.spots} ${translations[currentLang].spots_available}</span>
          </div>
          <button class="btn btn-primary join-activity-btn" data-activity="${translations[currentLang][act.titleKey]}" style="margin-top:8px;">${translations[currentLang].join_event}</button>
        </div>
      </div>
    `).join('');
    document.querySelectorAll('.join-activity-btn').forEach(btn => {
      btn.addEventListener('click', (e) => {
        const actTitle = btn.getAttribute('data-activity');
        let msg = translations[currentLang].toast_joined.replace("{activity}", actTitle);
        showToast(msg);
      });
    });
  }

  function showToast(message, duration = 3000) {
    let existingToast = document.querySelector('.message-toast');
    if(existingToast) existingToast.remove();
    const toast = document.createElement('div');
    toast.className = 'message-toast';
    toast.innerHTML = `<i class="fas fa-check-circle"></i> ${message}`;
    document.body.appendChild(toast);
    setTimeout(() => { if(toast) toast.remove(); }, duration);
  }

  // Donation & Contact forms with localized messages
  function setupDonationForm() {
    const form = document.getElementById('donationForm');
    const amountSelect = document.getElementById('donationAmount');
    const otherDiv = document.getElementById('otherAmountDiv');
    if(amountSelect) {
      amountSelect.addEventListener('change', function() {
        otherDiv.style.display = this.value === 'other' ? 'block' : 'none';
      });
    }
    if(form) {
      form.addEventListener('submit', (e) => {
        e.preventDefault();
        let donorName = document.getElementById('donorName')?.value.trim();
        let donorEmail = document.getElementById('donorEmail')?.value.trim();
        let selectedAmount = document.getElementById('donationAmount')?.value;
        let finalAmount = selectedAmount;
        if(selectedAmount === 'other') {
          let custom = document.getElementById('customAmount')?.value;
          if(!custom || custom <= 0) { showToast("⚠️ Please enter a valid custom amount."); return; }
          finalAmount = `$${custom}`;
        } else { finalAmount = `$${selectedAmount}`; }
        if(!donorName || !donorEmail) { showToast("❌ Please fill name and email."); return; }
        let msg = translations[currentLang].toast_donation_thanks.replace("{name}", donorName).replace("{amount}", finalAmount);
        showToast(msg);
        form.reset();
        if(otherDiv) otherDiv.style.display = 'none';
        if(amountSelect) amountSelect.value = "10";
      });
    }
  }

  function setupContactForm() {
    const contactForm = document.getElementById('contactForm');
    if(contactForm) {
      contactForm.addEventListener('submit', (e) => {
        e.preventDefault();
        const name = document.getElementById('contactName')?.value.trim();
        const email = document.getElementById('contactEmail')?.value.trim();
        const msg = document.getElementById('contactMsg')?.value.trim();
        if(!name || !email || !msg) { showToast("Please fill all contact fields."); return; }
        let thanksMsg = translations[currentLang].toast_contact_thanks.replace("{name}", name);
        showToast(thanksMsg);
        contactForm.reset();
      });
    }
  }

  // Page routing
  const pages = { home: document.getElementById('home-page'), gallery: document.getElementById('gallery-page'), events: document.getElementById('events-page'), activities: document.getElementById('activities-page'), aboutus: document.getElementById('aboutus-page'),donation: document.getElementById('donation-page'), contact: document.getElementById('contact-page') };
  function activatePage(pageId) {
    Object.values(pages).forEach(p => { if(p) p.classList.remove('active-page'); });
    if(pages[pageId]) pages[pageId].classList.add('active-page');
    document.querySelectorAll('.nav-btn').forEach(btn => { btn.classList.remove('active'); if(btn.getAttribute('data-page') === pageId) btn.classList.add('active'); });
    if(pageId === 'gallery') rendergallery();
    if(pageId === 'activities') renderActivities();
     if(pageId === 'events') renderEvents();
    if(pageId === 'aboutus') renderAboutus();
     if(pageId === 'donation') renderDonation();
    if(pageId === 'contact') renderContact();
  }
  document.querySelectorAll('.nav-btn').forEach(btn => { btn.addEventListener('click', (e) => { const page = btn.getAttribute('data-page'); if(page && pages[page]) activatePage(page); }); });
  document.getElementById('exploreHomeBtn')?.addEventListener('click', () => activatePage('home'));
  document.getElementById('joinGalleryBtn')?.addEventListener('click', () => activatePage('gallery'));
  document.getElementById('exploreEventsBtn')?.addEventListener('click', () => activatePage('events'));
  document.getElementById('joinActivitiesBtn')?.addEventListener('click', () => activatePage('activities'));
  document.getElementById('exploreAboutusBtn')?.addEventListener('click', () => activatePage('aboutus'));
  document.getElementById('joinDonationBtn')?.addEventListener('click', () => activatePage('donation'));
  document.getElementById('joinContactBtn')?.addEventListener('click', () => activatePage('contact'));


  // Language switcher
  function setLanguage(lang) {
    currentLang = lang;
    updatePageLanguage();
    rendergallery(); renderActivities();
    document.querySelectorAll('.lang-btn').forEach(btn => { btn.classList.remove('active'); if(btn.getAttribute('data-lang') === lang) btn.classList.add('active'); });
    // also refresh donation select other text and forms texts
    const amountSelect = document.getElementById('donationAmount');
    if(amountSelect && amountSelect.querySelector('option[value="other"]')) {
      amountSelect.querySelector('option[value="other"]').textContent = translations[currentLang].opt_other;
    }
  }
  document.querySelectorAll('.lang-btn').forEach(btn => { btn.addEventListener('click', () => setLanguage(btn.getAttribute('data-lang'))); });

  // initial render
  rendergallery(); renderEvents(); renderActivities(); setupDonationForm(); setupContactForm(); updatePageLanguage();
  setLanguage('en');

//########################################################


    // ============ SLIDESHOW IMPLEMENTATION ============
let currentSlide = 0;
let slides = [];
let dots = [];
let autoPlayInterval;
let progressInterval;
const slideDelay = 2000; // 2
//  seconds per slide

// Initialize slideshow
function initSlideshow() {
    slides = document.querySelectorAll('.slide');
    
    if (slides.length === 0) {
        console.error('No slides found!');
        return;
    }
    
    createDots();
    showSlide(currentSlide);
    startAutoPlay();
    
    // Add keyboard navigation
    document.addEventListener('keydown', (e) => {
        if (e.key === 'ArrowLeft') prevSlide();
        if (e.key === 'ArrowRight') nextSlide();
    });
}

// Create dot indicators
function createDots() {
    const dotsContainer = document.querySelector('.dots');
    if (!dotsContainer) return;
    
    dotsContainer.innerHTML = '';
    
    slides.forEach((_, index) => {
        const dot = document.createElement('div');
        dot.classList.add('dot');
        dot.addEventListener('click', () => goToSlide(index));
        dotsContainer.appendChild(dot);
    });
    
    dots = document.querySelectorAll('.dot');
}

// Update active dot
function updateDots() {
    dots.forEach((dot, index) => {
        if (index === currentSlide) {
            dot.classList.add('active');
        } else {
            dot.classList.remove('active');
        }
    });
}

// Show specific slide
function showSlide(index) {
    // Remove active class from all slides
    slides.forEach(slide => {
        slide.classList.remove('active');
    });
    
    // Add active class to current slide
    if (slides[index]) {
        slides[index].classList.add('active');
    }
    
    // Update dots
    updateDots();
    
    // Reset progress bar
    resetProgressBar();
}

// Go to next slide
function nextSlide() {
    currentSlide = (currentSlide + 1) % slides.length;
    showSlide(currentSlide);
    resetAutoPlay();
}

// Go to previous slide
function prevSlide() {
    currentSlide = (currentSlide - 1 + slides.length) % slides.length;
    showSlide(currentSlide);
    resetAutoPlay();
}

// Go to specific slide
function goToSlide(index) {
    currentSlide = index;
    showSlide(currentSlide);
    resetAutoPlay();
}

// Start auto-play
function startAutoPlay() {
    if (autoPlayInterval) clearInterval(autoPlayInterval);
    
    autoPlayInterval = setInterval(() => {
        nextSlide();
    }, slideDelay);
    
    startProgressBar();
}

// Reset auto-play timer
function resetAutoPlay() {
    clearInterval(autoPlayInterval);
    clearInterval(progressInterval);
    startAutoPlay();
}

// Progress bar animation
function startProgressBar() {
    const progressBar = document.querySelector('.progress-bar');
    if (!progressBar) return;
    
    progressBar.style.width = '0%';
    
    let startTime = Date.now();
    
    progressInterval = setInterval(() => {
        const elapsed = Date.now() - startTime;
        const percentage = (elapsed / slideDelay) * 100;
        
        if (percentage <= 100) {
            progressBar.style.width = percentage + '%';
        } else {
            clearInterval(progressInterval);
        }
    }, 10);
}

// Reset progress bar
function resetProgressBar() {
    clearInterval(progressInterval);
    const progressBar = document.querySelector('.progress-bar');
    if (progressBar) {
        progressBar.style.width = '0%';
        startProgressBar();
    }
}

// Add event listeners for navigation buttons
function setupNavigationButtons() {
    const prevBtn = document.querySelector('.nav-prev');
    const nextBtn = document.querySelector('.nav-next');
    
    if (prevBtn) {
        prevBtn.addEventListener('click', prevSlide);
    }
    
    if (nextBtn) {
        nextBtn.addEventListener('click', nextSlide);
    }
}

// Pause on hover
function setupHoverPause() {
    const container = document.querySelector('.hero-slideshow');
    if (container) {
        container.addEventListener('mouseenter', () => {
            clearInterval(autoPlayInterval);
            clearInterval(progressInterval);
        });
        
        container.addEventListener('mouseleave', () => {
            startAutoPlay();
        });
    }
}

// Initialize everything when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    initSlideshow();
    setupNavigationButtons();
    setupHoverPause();
});